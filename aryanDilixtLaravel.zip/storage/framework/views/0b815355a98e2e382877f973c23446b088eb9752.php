<div class="p-5 m-5">
    <button wire:click="addSongBtn" class="btn btn-success">Add new song</button>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Yt Link</th>
            <th scope="col">Title</th>
            <th scope="col">Description</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <th scope="row"><?php echo e($index + 1); ?></th>
                <td><?php echo e($link->link); ?></td>
                <td><?php echo e($link->title); ?></td>
                <td><?php echo e($link->description); ?></td>
                <td>
                    <button wire:click="edit(<?php echo e($link->id); ?>)" class="btn btn-primary">edit</button>
                    <button wire:click="delete(<?php echo e($link->id); ?>)" class="btn btn-danger">delete</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2>No songs added</h2>
        <?php endif; ?>
        </tbody>
    </table>

    <?php if(session('saved')): ?>
    <div class="alert alert-primary">
        <?php echo e(session('saved')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('updated')): ?>
    <div class="alert alert-primary">
        <?php echo e(session('updated')); ?>

    </div>
    <?php endif; ?>

    <?php if($addsongDiv): ?>
    <div class="w-50">
        <form wire:submit.prevent="addSong">
            <div class="form-group">
                <input type="text" class="form-control" id="inputAddress" placeholder="Youtube Link" wire:model="link">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="inputAddress2" placeholder="Title" wire:model="title">
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputCity">Description</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" wire:model="description"></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Add</button>
        </form>
    </div>
    <?php endif; ?>
    <?php if($editSongDiv): ?>
        <div class="w-50">
            <form wire:submit.prevent="updateSong">
                <div class="form-group">
                    <input type="text" class="form-control" id="inputAddress" placeholder="Youtube Link" wire:model="editLink">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" id="inputAddress2" placeholder="Title" wire:model="editTitle">
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputCity">Description</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" wire:model="editDescription"></textarea>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH D:\aryanDilixtLaravel\resources\views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>