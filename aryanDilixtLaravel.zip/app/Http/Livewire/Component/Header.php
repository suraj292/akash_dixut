<?php

namespace App\Http\Livewire\Component;

use Livewire\Component;

class Header extends Component
{
    public function render()
    {
        return view('livewire.component.header');
    }
}
