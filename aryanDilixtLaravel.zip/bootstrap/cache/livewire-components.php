<?php return array (
  'admin.dashboard' => 'App\\Http\\Livewire\\Admin\\Dashboard',
  'admin.login' => 'App\\Http\\Livewire\\Admin\\Login',
  'component.footer' => 'App\\Http\\Livewire\\Component\\Footer',
  'component.header' => 'App\\Http\\Livewire\\Component\\Header',
  'home' => 'App\\Http\\Livewire\\Home',
  'songs' => 'App\\Http\\Livewire\\Songs',
);